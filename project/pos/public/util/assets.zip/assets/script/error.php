<?php
/*
$user="";
$pass="";
//Ya tenemos usuario y password
/*Si queremos generar un enlace hacia esa web usamos
echo "<a href='otrapag.php?user=$user&pass=$pass'> DIRECCION DEL VINCULO </a>";
*/


header("Location: https://admin.multi-marcas.com");

 ?>