Products Comparison Table
=========

A responsive table to compare and filter through multiple products.

[Article on CodyHouse](https://codyhouse.co/gem/products-comparison-table/)

[Demo](https://codyhouse.co/demo/products-comparison-table/index.html)
 
[Terms](https://codyhouse.co/terms/)
