<?php $comentario = $_REQUEST["comentario"];
?>